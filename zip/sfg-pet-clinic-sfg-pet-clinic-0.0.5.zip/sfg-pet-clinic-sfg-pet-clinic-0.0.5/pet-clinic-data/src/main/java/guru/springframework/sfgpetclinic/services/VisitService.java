package guru.springframework.sfgpetclinic.services;

import guru.springframework.sfgpetclinic.model.Visit;

/**
 * Created by jt on 8/7/18.
 */
public interface VisitService extends CrudService<Visit, Long> {
}
