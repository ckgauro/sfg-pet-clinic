package com.gauro.sfgpetclinic.model;

/**
 * @author Chandra
 */
public class Owner extends Person {
}
