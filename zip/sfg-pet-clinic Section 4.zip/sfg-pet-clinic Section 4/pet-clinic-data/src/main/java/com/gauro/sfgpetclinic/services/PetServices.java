package com.gauro.sfgpetclinic.services;

import com.gauro.sfgpetclinic.model.Owner;
import com.gauro.sfgpetclinic.model.Pet;

import java.util.Set;

/**
 * @author Chandra
 */
public interface PetServices extends CrudService<Pet, Long>{

}
