package com.gauro.sfgpetclinic.model;

/**
 * @author Chandra
 */
public class Vet extends Person{

}
